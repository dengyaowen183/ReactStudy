import React, { Component } from 'react';
import $ from 'jquery';
import ProvinceSelect from './Components/ProvinceSelect';

import './App.css';

class App extends Component {
  getAreaData(){
    $.ajax({
      type:'GET',
      url:'../Datas/area.json',
      dataType:'json',
      success:function(data){
        console.log(data);
      },
      error:function(xhr,msg,err){

      }
    });
  }
  componentDidMount(){
    this.getAreaData();
  }

  render(){
    return (
      <div className="App">
        <h3>React 生命周期</h3>
        <img src="./react_life.jpg" />
        <h3>省市县联动</h3>
        <ProvinceSelect />
      </div>
    );
  }
}

export default App;
